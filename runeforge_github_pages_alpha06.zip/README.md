# Runeforge Empire – Alpha 0.6

Gratis testversion för iPhone Safari. Arbetsnamn; varumärke inte klarerat.

## Publicera gratis med GitHub Pages
1. Skapa ett **public** repository på GitHub, t.ex. `runeforge-empire-demo`.
2. Ladda upp `index.html` och mappen `.github` från detta paket till repositoryts huvudgren (eller ladda upp hela innehållet med Git).
3. Öppna repositoryts **Settings → Pages → Build and deployment → Source** och välj **GitHub Actions**.
4. Vänta på att workflow `Deploy Runeforge demo` slutförs under **Actions**.
5. Öppna `https://DITT-ANVANDARNAMN.github.io/runeforge-empire-demo/` i Safari på din iPhone. Ersätt användarnamn och repositorynamn med dina egna.

GitHub Pages för gratis konton kräver normalt ett publikt repository. Koden blir offentlig. GitHub-konto krävs; inget betalkonto eller domän krävs.

## Spela
Dra den runda joysticken för mjuk 360-graders rörelse. Empire-menyn hanterar gruva, smedja och försäljning. Hjälte-menyn innehåller en enkel goblinstrid. Settings växlar styrsätt. Spelet sparar lokalt i webbläsaren (kan försvinna om webbplatsdata rensas).

## Felsökning
Om kartan inte syns: öppna sidan direkt i Safari via publicerad HTTPS-adress, inte via ChatGPT:s HTML-förhandsvisning. Om det fortfarande inte fungerar, ta en skärmbild och ange iPhone/iOS-version. Detta är en prototyp och har inte verifierats på fysisk iPhone.
